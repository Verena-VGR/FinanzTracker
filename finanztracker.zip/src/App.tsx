/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  PlusCircle, 
  TrendingUp, 
  TrendingDown, 
  Filter, 
  Trash2, 
  PieChart as PieChartIcon, 
  Calendar,
  ChevronDown,
  ChevronUp,
  Euro,
  Wallet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend 
} from 'recharts';
import { Transaction, TransactionType, Category } from './types';

const CATEGORIES: Category[] = [
  'Miete',
  'Strom / Gas',
  'Internet - Handy',
  'Versicherungen',
  'Mobilität - Auto',
  'Lebensmittel',
  'Drogerie & Beauty',
  'Shopping',
  'Freizeit',
  'Gastronomie',
  'Sonstiges',
  'Sparen'
];

const INCOME_CATEGORIES: Category[] = [
  'Gehalt',
  'Geschenke'
];

const EXPENSE_COLORS = [
  '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', 
  '#d946ef', '#ec4899', '#f43f5e', '#f97316', '#eab308', 
  '#06b6d4', '#64748b', '#94a3b8'
];

const INCOME_COLORS = [
  '#059669', '#10b981', '#34d399', '#6ee7b7', '#a7f3d0'
];

export default function App() {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('finanz_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    type: 'Ausgabe' as TransactionType,
    category: 'Lebensmittel' as Category,
    description: '',
    amount: '',
    isFixed: false
  });

  const [filterMonth, setFilterMonth] = useState<number>(new Date().getMonth() + 1);
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [isFormOpen, setIsFormOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('finanz_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    setFormData(prev => {
      const newData = { ...prev, [name]: val };
      if (name === 'type' && value === 'Einnahme') {
        newData.category = 'Gehalt';
      } else if (name === 'type' && value === 'Ausgabe' && (prev.category === 'Gehalt' || prev.category === 'Geschenke')) {
        newData.category = 'Lebensmittel';
      }
      return newData;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || parseFloat(formData.amount) <= 0) return;

    const dateObj = new Date(formData.date);
    const newTransaction: Transaction = {
      id: crypto.randomUUID(),
      date: formData.date,
      type: formData.type,
      category: formData.category,
      description: formData.description,
      amount: parseFloat(formData.amount),
      month: dateObj.getMonth() + 1,
      year: dateObj.getFullYear(),
      isFixed: formData.isFixed
    };

    const newTransactions = [newTransaction];

    // If it's a fixed cost, add it to the next month as well
    if (formData.isFixed) {
      const nextMonthDate = new Date(dateObj);
      nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
      
      const nextTransaction: Transaction = {
        ...newTransaction,
        id: crypto.randomUUID(),
        date: nextMonthDate.toISOString().split('T')[0],
        month: nextMonthDate.getMonth() + 1,
        year: nextMonthDate.getFullYear(),
      };
      newTransactions.push(nextTransaction);
    }

    setTransactions(prev => [...newTransactions, ...prev]);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      type: 'Ausgabe',
      category: 'Lebensmittel',
      description: '',
      amount: '',
      isFixed: false
    });
    setIsFormOpen(false);
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const filteredTransactions = useMemo(() => {
    return transactions
      .filter(t => t.month === filterMonth && t.year === filterYear)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, filterMonth, filterYear]);

  const stats = useMemo(() => {
    const income = filteredTransactions
      .filter(t => t.type === 'Einnahme')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const expenses = filteredTransactions
      .filter(t => t.type === 'Ausgabe')
      .reduce((sum, t) => sum + t.amount, 0);

    const categoryTotals = CATEGORIES.reduce((acc, cat) => {
      acc[cat] = filteredTransactions
        .filter(t => t.category === cat)
        .reduce((sum, t) => sum + t.amount, 0);
      return acc;
    }, {} as Record<string, number>);

    const incomeCategoryTotals = INCOME_CATEGORIES.reduce((acc, cat) => {
      acc[acc[cat] ? '' : cat] = filteredTransactions
        .filter(t => t.type === 'Einnahme' && t.category === cat)
        .reduce((sum, t) => sum + t.amount, 0);
      return acc;
    }, {} as Record<string, number>);

    const savings = categoryTotals['Sparen'] || 0;
    // Real expenses are total expenses minus savings
    const realExpenses = expenses - savings;

    const expenseChartData = CATEGORIES
      .map(cat => ({ name: cat, value: categoryTotals[cat] || 0, type: 'Ausgabe' }))
      .filter(item => item.value > 0);

    const incomeChartData = INCOME_CATEGORIES
      .map(cat => ({ name: cat, value: incomeCategoryTotals[cat] || 0, type: 'Einnahme' }))
      .filter(item => item.value > 0);

    const combinedChartData = [...incomeChartData, ...expenseChartData];

    return { 
      income, 
      expenses, 
      balance: income - expenses, 
      categoryTotals, 
      incomeCategoryTotals,
      savings, 
      realExpenses,
      combinedChartData
    };
  }, [filteredTransactions]);

  const years = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const transactionYears = transactions.map(t => t.year);
    const allYears = Array.from(new Set([currentYear, ...transactionYears])).sort((a, b) => b - a);
    return allYears;
  }, [transactions]);

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-slate-900 font-sans pb-12">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-white shadow-sm">
              <TrendingUp size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight">FinanzTracker</h1>
          </div>
          <button 
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="p-2 bg-slate-900 text-white rounded-full hover:bg-slate-800 transition-colors shadow-md"
          >
            {isFormOpen ? <ChevronUp size={24} /> : <PlusCircle size={24} />}
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 mt-6 space-y-6">
        
        {/* Add Transaction Form */}
        <AnimatePresence>
          {isFormOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Datum</label>
                    <input 
                      type="date" 
                      name="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Typ</label>
                    <select 
                      name="type"
                      value={formData.type}
                      onChange={handleInputChange}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    >
                      <option value="Ausgabe">Ausgabe</option>
                      <option value="Einnahme">Einnahme</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kategorie</label>
                    <select 
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all disabled:opacity-50"
                    >
                      {formData.type === 'Einnahme' ? (
                        <>
                          <option value="Gehalt">Gehalt</option>
                          <option value="Geschenke">Geschenke</option>
                        </>
                      ) : (
                        CATEGORIES.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))
                      )}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Betrag (€)</label>
                    <input 
                      type="number" 
                      name="amount"
                      step="0.01"
                      placeholder="0.00"
                      value={formData.amount}
                      onChange={handleInputChange}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Beschreibung</label>
                  <div className="flex gap-4 items-center">
                    <input 
                      type="text" 
                      name="description"
                      placeholder="z.B. Wocheneinkauf"
                      value={formData.description}
                      onChange={handleInputChange}
                      className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    />
                    <label className="flex items-center gap-2 cursor-pointer select-none shrink-0">
                      <input 
                        type="checkbox" 
                        name="isFixed"
                        checked={formData.isFixed}
                        onChange={handleInputChange}
                        className="w-5 h-5 rounded border-slate-300 text-emerald-500 focus:ring-emerald-500"
                      />
                      <span className="text-sm font-medium text-slate-600">Fixkosten?</span>
                    </label>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full py-3 bg-emerald-500 text-white font-bold rounded-xl hover:bg-emerald-600 transition-colors shadow-lg shadow-emerald-500/20"
                >
                  Eintrag speichern
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Filters */}
        <div className="flex gap-3 items-center overflow-x-auto pb-2 scrollbar-hide">
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm shrink-0">
            <Calendar size={16} className="text-slate-400" />
            <select 
              value={filterMonth}
              onChange={(e) => setFilterMonth(parseInt(e.target.value))}
              className="bg-transparent outline-none text-sm font-medium"
            >
              {Array.from({ length: 12 }, (_, i) => i + 1).map(m => (
                <option key={m} value={m}>
                  {new Date(2000, m - 1).toLocaleString('de-DE', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm shrink-0">
            <Filter size={16} className="text-slate-400" />
            <select 
              value={filterYear}
              onChange={(e) => setFilterYear(parseInt(e.target.value))}
              className="bg-transparent outline-none text-sm font-medium"
            >
              {years.map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Einnahmen</p>
            <p className="text-2xl font-bold text-emerald-600">+{stats.income.toFixed(2)} €</p>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Ausgaben</p>
            <p className="text-2xl font-bold text-rose-500">-{stats.realExpenses.toFixed(2)} €</p>
          </div>
          <div className="bg-indigo-50 p-5 rounded-2xl border border-indigo-100 shadow-sm">
            <p className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-1">Sparen</p>
            <p className="text-2xl font-bold text-indigo-600">{stats.savings.toFixed(2)} €</p>
          </div>
          <div className={`p-5 rounded-2xl border shadow-sm ${stats.balance >= 0 ? 'bg-emerald-50 border-emerald-100' : 'bg-rose-50 border-rose-100'}`}>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Differenz</p>
            <p className={`text-2xl font-bold ${stats.balance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {stats.balance >= 0 ? '+' : ''}{stats.balance.toFixed(2)} €
            </p>
          </div>
        </div>

        {/* Charts Section */}
        {stats.combinedChartData.length > 0 && (
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <PieChartIcon size={18} className="text-slate-400" />
              <h2 className="font-bold text-slate-800">Gesamtübersicht (Einnahmen & Ausgaben)</h2>
            </div>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.combinedChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {stats.combinedChartData.map((entry, index) => {
                      const color = entry.type === 'Einnahme' 
                        ? INCOME_COLORS[index % INCOME_COLORS.length]
                        : EXPENSE_COLORS[index % EXPENSE_COLORS.length];
                      return <Cell key={`cell-${index}`} fill={color} />;
                    })}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number, name: string, props: any) => [
                      `${value.toFixed(2)} €`, 
                      `${props.payload.name} (${props.payload.type})`
                    ]}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Income Breakdown */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <Wallet size={18} className="text-slate-400" />
            <h2 className="font-bold text-slate-800">Einnahmen nach Kategorie</h2>
          </div>
          <div className="space-y-3">
            {stats.income === 0 ? (
              <p className="text-sm text-slate-400 italic">Keine Einnahmen in diesem Zeitraum</p>
            ) : (
              INCOME_CATEGORIES.map(cat => {
                const total = stats.incomeCategoryTotals[cat] || 0;
                if (total === 0) return null;
                const percentage = stats.income > 0 ? (total / stats.income) * 100 : 0;
                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-slate-600">{cat}</span>
                      <span className="font-bold text-emerald-600">+{total.toFixed(2)} €</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${percentage}%` }}
                        className="h-full bg-emerald-500 rounded-full"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <PieChartIcon size={18} className="text-slate-400" />
            <h2 className="font-bold text-slate-800">Ausgaben nach Kategorie</h2>
          </div>
          <div className="space-y-3">
            {CATEGORIES.map(cat => {
              const total = stats.categoryTotals[cat] || 0;
              const percentage = stats.expenses > 0 ? (total / stats.expenses) * 100 : 0;
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className={`font-medium ${cat === 'Sparen' ? 'text-indigo-600 font-bold' : 'text-slate-600'}`}>{cat}</span>
                    <span className={`font-bold ${cat === 'Sparen' ? 'text-indigo-700' : 'text-slate-900'}`}>{total.toFixed(2)} €</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${percentage}%` }}
                      className={`h-full rounded-full ${cat === 'Sparen' ? 'bg-indigo-500' : 'bg-slate-400'}`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Transaction List */}
        <div className="space-y-4">
          <h2 className="font-bold text-slate-800 flex items-center gap-2">
            <Euro size={18} className="text-slate-400" />
            Transaktionen
          </h2>
          <div className="space-y-3">
            {filteredTransactions.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
                <p className="text-slate-400 font-medium">Keine Einträge für diesen Zeitraum</p>
              </div>
            ) : (
              filteredTransactions.map(t => (
                <motion.div 
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={t.id}
                  className={`p-4 rounded-2xl border shadow-sm flex justify-between items-center group ${
                    t.category === 'Sparen' 
                      ? 'bg-indigo-50/50 border-indigo-100' 
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      t.type === 'Einnahme' 
                        ? 'bg-emerald-100 text-emerald-600' 
                        : t.category === 'Sparen'
                        ? 'bg-indigo-100 text-indigo-600'
                        : 'bg-slate-100 text-slate-600'
                    }`}>
                      {t.type === 'Einnahme' ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className={`font-bold ${t.category === 'Sparen' ? 'text-indigo-900' : 'text-slate-900'}`}>
                          {t.description || t.category}
                        </p>
                        {t.isFixed && (
                          <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-[10px] font-bold uppercase tracking-wider rounded border border-slate-200">
                            Fix
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                        <span>{new Date(t.date).toLocaleDateString('de-DE')}</span>
                        <span>•</span>
                        <span className={t.category === 'Sparen' ? 'text-indigo-400' : ''}>{t.category}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <p className={`font-bold text-lg ${
                      t.type === 'Einnahme' 
                        ? 'text-emerald-600' 
                        : t.category === 'Sparen'
                        ? 'text-indigo-600'
                        : 'text-slate-900'
                    }`}>
                      {t.type === 'Einnahme' ? '+' : '-'}{t.amount.toFixed(2)} €
                    </p>
                    <button 
                      onClick={() => deleteTransaction(t.id)}
                      className={`p-2 transition-colors opacity-0 group-hover:opacity-100 ${
                        t.category === 'Sparen' ? 'text-indigo-300 hover:text-rose-500' : 'text-slate-300 hover:text-rose-500'
                      }`}
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
