export type TransactionType = 'Einnahme' | 'Ausgabe';

export type Category = 
  | 'Mobilität - Auto' 
  | 'Lebensmittel' 
  | 'Drogerie & Beauty' 
  | 'Shopping' 
  | 'Freizeit' 
  | 'Gastronomie'
  | 'Internet - Handy'
  | 'Versicherungen'
  | 'Miete'
  | 'Strom / Gas'
  | 'Sonstiges'
  | 'Sparen'
  | 'Gehalt'
  | 'Geschenke';

export interface Transaction {
  id: string;
  date: string;
  type: TransactionType;
  category: Category;
  description: string;
  amount: number;
  month: number;
  year: number;
  isFixed?: boolean;
}
